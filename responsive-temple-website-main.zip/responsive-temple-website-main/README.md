# Responsive Temple Website
## [Watch it on youtube](https://youtu.be/bDUhw9mgvaU)
### Responsive Temple Website

- Responsive Temple Website Design Using HTML CSS And JavaScript
- Contains animated images with the Gsap Js library.
- Contains animated petals with the Sakura Js library.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
